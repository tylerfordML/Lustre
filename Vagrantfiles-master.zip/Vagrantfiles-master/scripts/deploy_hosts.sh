#!/bin/bash

iml server add --hosts mds[1,2].local,oss[1,2].local --profile $1
