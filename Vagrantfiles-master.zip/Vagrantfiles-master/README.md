# Vagrantfiles

## Deprecated

This repo has been moved into https://github.com/whamcloud/integrated-manager-for-lustre/tree/master/vagrant
